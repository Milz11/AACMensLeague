document.getElementById("statForm").addEventListener("submit", function(e) {
  e.preventDefault();
  alert("Stats submitted (not really, this is just a static example).");
});